My name is Abdur Rahim (abir)
Roll: 1810576141

how to run my code to get result
first compile all

1) gcc Blackhole.c -o Blackhole -pthread
2) gcc Nebula.c -o Nebula -pthread
3) gcc Galaxy.c -o Galaxy -pthread

now run the main program Galaxy
**) sudo ./Galaxy

Note: why i used sudo before running galaxy because i used set scheduler function in Nebula.c which need root permission so 
as galaxy is going to use nebula i gave it root permission.